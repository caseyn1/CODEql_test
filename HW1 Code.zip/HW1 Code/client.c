#include <sys/select.h>
#include <sys/socket.h>
#include <stdio.h>
#include <string.h>
#include <netinet/in.h>
#include <unistd.h>
#include <netdb.h>   // gethostbyname()
#include <arpa/inet.h>

#define SERVER_PORT     3005
#define BUFFER_LENGTH    250
#define FALSE              0
#define SERVER_NAME     "localhost"
#define MAX_HOST_NAME_LENGTH 20


int main(int argc, char *argv[]) {
   int    sd=-1, rc, bytesReceived;
   char   buffer[BUFFER_LENGTH];
   char   server[MAX_HOST_NAME_LENGTH];
   struct sockaddr_in serveraddr;
   struct hostent *hostp;

   do   {
      // Create a socket for communication using IPv4 and TCP
      sd = socket(AF_INET, SOCK_STREAM, 0);
      //test error sd < 0

      // Determine the server name or IP address to connect to
      if (argc > 1)  strcpy(server, argv[1]);
      else  strcpy(server, SERVER_NAME);

      // Initialize the server address structure to zero
      memset(&serveraddr, 0, sizeof(serveraddr));
      serveraddr.sin_family      = AF_INET;               // Use IPv4
      serveraddr.sin_port        = htons(SERVER_PORT);    // Set server port with network byte order
      serveraddr.sin_addr.s_addr = inet_addr(server);     // Convert server string IP to binary form

      // If inet_addr returns INADDR_NONE, the server string is not a valid IP
      if (serveraddr.sin_addr.s_addr == (unsigned long)INADDR_NONE)      {
         hostp = gethostbyname(server);
         if (hostp == (struct hostent *)NULL) {
            printf("Host not found --> ");
            break; 
         }

         memcpy(&serveraddr.sin_addr,
                hostp->h_addr,
                sizeof(serveraddr.sin_addr));
      }

      // Attempt to connect to the server using the specified address and port
      rc = connect(sd, (struct sockaddr *)&serveraddr, sizeof(serveraddr));
      // test error rc < 0

      printf("Connect returned %d\n", rc);

      // Fill the buffer with 'a' characters to prepare data for sending
      memset(buffer, 'a', sizeof(buffer));
      // Send the entire buffer to the server
      rc = send(sd, buffer, sizeof(buffer), 0);
      // test error rc < 0

      printf("send returned %d\n", rc);
     
       bytesReceived = 0;
       // Loop to receive the full BUFFER_LENGTH bytes from the server
       while (bytesReceived < BUFFER_LENGTH) {
             // Receive data into buffer starting at the offset bytesReceived
             rc = recv(sd, & buffer[bytesReceived],
                    BUFFER_LENGTH - bytesReceived, 0);
             // test error rc < 0 or rc == 0
             printf("bytes received %d\n", rc);

              // Increment bytesReceived by the number of bytes just received
              bytesReceived += rc;
        }

   } while (FALSE);

//    shutdown(sd, SHUT_RDWR);

    // Close the socket if it was successfully created
    if (sd != -1)
      close(sd);
}
