#include <sys/select.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>    
#include <netinet/in.h>
#include <unistd.h>
#include <openssl/sha.h>


#define SERVER_PORT     3005
#define BUFFER_LENGTH    250
#define FALSE              0
typedef unsigned char byte;

int  main() {
   int    sd=-1, sd2=-1;
   int    rc, length, on=1;
   char   buffer[BUFFER_LENGTH];
   fd_set read_fd;
   struct timeval timeout;
   struct sockaddr_in serveraddr;

   sd = socket(AF_INET, SOCK_STREAM, 0);
   // test error: sd < 0)      

   memset(&serveraddr, 0, sizeof(serveraddr));
   serveraddr.sin_family      = AF_INET;
   serveraddr.sin_port        = htons(SERVER_PORT);
   serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);

   rc = bind(sd, (struct sockaddr *)&serveraddr, sizeof(serveraddr));
   // test error rc < 0

   rc = listen(sd, 10);
   // test error rc< 0

   printf("Ready for client connect().\n");

   do {

      sd2 = accept(sd, NULL, NULL);
      // test error sd2 < 0

      timeout.tv_sec  = 0;
      timeout.tv_usec = 0;

      FD_ZERO(&read_fd);
      FD_SET(sd2, &read_fd);

      rc = select(1, &read_fd, NULL, NULL, &timeout);
      // test error rc < 0

      length = BUFFER_LENGTH;
 
      rc = recv(sd2, buffer, sizeof(buffer), 0);
      // test error rc < 0 or rc == 0 or   rc < sizeof(buffer
      printf("server received %d bytes\n", rc);
      int found = 0;
      for(int pin = 0; pin <10000; pin++) {
         SHA_CTX shactx;
      
      
         SHA1_Init(&shactx);
         byte digest[SHA_DIGEST_LENGTH];
         char hexstring[SHA_DIGEST_LENGTH*2+1];
         if(pin >= 0 && pin < 10) {
            char s[2];
            sprintf(s, "%d", pin);
            SHA1_Update(&shactx, s, 1);
         } else if(pin >=10 && pin < 99) {
            char s[3];
            sprintf(s, "%d", pin);
            SHA1_Update(&shactx, s, 2);
         } else if(pin >=100 && pin < 999) {
            char s[4];
            sprintf(s, "%d", pin);
            SHA1_Update(&shactx, s, 3);
         } else if(pin >=1000 && pin < 10000) {
            char s[5];
            sprintf(s, "%d", pin);
            SHA1_Update(&shactx, s, 4);
         }
         SHA1_Final(digest, &shactx);

         for (int i=0; i<SHA_DIGEST_LENGTH; i++) 
	         sprintf(&hexstring[i*2], "%02x", digest[i]);
           
         hexstring[SHA_DIGEST_LENGTH*2] = '\0';
         if(strcmp(hexstring, buffer) == 0) {
            printf("PIN found: %d\n", pin);
            found = 1;
            break;
         }
         
      }
      if(found){
         int ret =1;
         send(sd2, &ret, sizeof(ret), 0);
         found = 0;
      }
      else {
         int ret = -1;
         send(sd2, &ret, sizeof(ret), 0);
         found = 0;
      }
      int ret = -1;
      send(sd2, &ret, sizeof(ret), 0);

      //rc = send(sd2, buffer, sizeof(buffer), 0);
      // test error rc < 0
      close(sd2);
      sd2 = -1;

   } while (1);

   if (sd != -1)
      close(sd);
   if (sd2 != -1)
      close(sd2);
}


